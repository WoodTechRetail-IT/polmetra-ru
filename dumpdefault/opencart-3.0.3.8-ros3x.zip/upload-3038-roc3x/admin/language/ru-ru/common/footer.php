<?php
// Text
$_['text_footer']  = '<HR><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Все права защищены.<br> <BR> <a href="https://opencart-3x.ru" target="_blank">Русский OpenCart 3x</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="https://opencart-3x.ru/blog/" target="_blank">Сайт поддержки</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="https://opencart-3x.ru" target="_blank">Магазин дополнений</a>';
$_['text_version'] = 'Version %s';

