<?php
// Heading
$_['heading_title']	   = 'Klarna Checkout';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']	   = 'Success: You have modified module Klarna Checkout!';

//Entry
$_['entry_status']	   = 'Status';

//Error
$_['error_permission'] = 'Warning: You do not have permission to modify Klarna Checkout module!';