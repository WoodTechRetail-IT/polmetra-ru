<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Акции';

// Text
$_['text_empty']        = 'Нет специальных предложений.';
$_['text_quantity']     = 'Кол-во:';
$_['text_manufacturer'] = 'Производитель:';
$_['text_model']        = 'Код Товара:';
$_['text_points']       = 'Бонусные баллы:';
$_['text_price']        = 'Цена:';
$_['text_tax']          = 'Без НДС:';
$_['text_compare']      = 'Сравнение товаров (%s)';
$_['text_sort']         = 'Сортировка:';
$_['text_default']      = 'По умолчанию';
$_['text_name_asc']     = 'Название (А - Я)';
$_['text_name_desc']    = 'Название (Я - А)';
$_['text_price_asc']    = 'Цена (низкая &gt; высокая)';
$_['text_price_desc']   = 'Цена (высокая &gt; низкая)';
$_['text_rating_asc']   = 'Рейтинг (начиная с низкого)';
$_['text_rating_desc']  = 'Рейтинг (начиная с высокого)';
$_['text_model_asc']    = 'Код Товара (А - Я)';
$_['text_model_desc']   = 'Код Товара (Я - А)';
				
			$_['button_price'] = 'Прайслист';
			
$_['text_limit']        = 'Показать:';
$_['text_benefits']     = 'Преимущества:';