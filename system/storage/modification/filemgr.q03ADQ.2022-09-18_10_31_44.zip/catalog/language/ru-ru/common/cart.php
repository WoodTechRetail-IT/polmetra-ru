<?php

	$_['text_print'] = 'Распечатать';
	

	$_['text_print'] = 'Распечатать';
	
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_items']     = 'Товаров: %s (%s)';
$_['text_empty']     = 'Ваша корзина пуста!';
$_['text_cart']      = 'Посмотреть корзину';
$_['text_checkout']  = 'Оформление заказа';
$_['text_recurring'] = 'Платежный профиль';